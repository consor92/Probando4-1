# proyecto-mini-arcade

Proyecto: Mini Arcade con Arduino

Número de Grupo: 6

Integrantes: Nicolás Nieto, Diego Saracino, Kiara Chunga

Curso y División: 4to 1ra C

Ciclo Lectivo: 2021
